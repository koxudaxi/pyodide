import sys
from fontTools.varLib.instancer import main

if __name__ == "__main__":
    sys.exit(main())
