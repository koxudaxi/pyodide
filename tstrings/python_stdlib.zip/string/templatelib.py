"""Support for template string literals (t-strings)."""

from _templatelib import Interpolation, Template
