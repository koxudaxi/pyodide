from _templatelib import Template, Interpolation

__all__ = ['Template', 'Interpolation']
